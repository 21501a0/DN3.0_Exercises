package com.library;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BookService {
    private BookRepository bookRepository;

    // Constructor-based dependency injection
    @Autowired
    public BookService(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    // Default constructor (for demonstration)
    public BookService() {}

    // Setter-based dependency injection
    @Autowired
    public void setBookRepository(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    // Method to indicate successful configuration
    public void performService() {
        // Implement service logic here
        System.out.println("Successfully Ran the LibraryManagementApplication main class to verify both constructor and setter injection.");
    }
}
