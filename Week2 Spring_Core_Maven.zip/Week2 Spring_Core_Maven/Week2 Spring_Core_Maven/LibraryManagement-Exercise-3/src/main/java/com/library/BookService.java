package com.library;

import com.library.BookRepository;

public class BookService {
    private BookRepository bookRepository;

    public void setBookRepository(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    public void performService() {
        // Implement service logic here
        System.out.println("Service is performing...");
        if (bookRepository != null) {
            System.out.println("BookRepository is successfully injected into BookService.");
        } else {
            System.out.println("BookRepository is not injected.");
        }
    }
}

