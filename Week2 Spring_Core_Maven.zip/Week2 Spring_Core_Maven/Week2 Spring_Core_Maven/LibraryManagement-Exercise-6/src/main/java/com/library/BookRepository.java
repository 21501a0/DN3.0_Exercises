package com.library;

import org.springframework.stereotype.Repository;

@Repository
public class BookRepository {
    // Implement repository logic here
}
